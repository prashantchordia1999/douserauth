

<!DOCTYPE HTML>
<html>
	<head>
		<title>Mucoeh | Home</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>

		<!-- Header -->
			<div id="header">

				<div class="top">

					<!-- Logo -->
						<div id="logo">
							<span class=""><img src="" alt="" /></span>
							<h1 id="title" style="text-align: center;font-size: 60px;">Mucoeh</h1>
							<p style="text-align: center;"><strong>MU&nbsp;</strong>-&nbsp;Multiple&nbsp;<strong>CO&nbsp;</strong>-&nbsp;College&nbsp;<br><strong>E&nbsp;</strong>-&nbsp;Event&nbsp;<strong>H&nbsp;</strong>-&nbsp;Hoster<br />
								<br>
				            "For The New Era of Competitons"</p>
						</div>

					<!-- Nav -->
						<nav id="nav">
							<!--

								1. Hash link (scrolls to a different section within the page)

								   <li><a href="#foobar" id="foobar-link" class="icon fa-whatever-icon-you-want skel-layers-ignoreHref"><span class="label">Foobar</span></a></li>

								2. Standard link (sends the user to another page/site)

								   <li><a href="http://foobar.tld" id="foobar-link" class="icon fa-whatever-icon-you-want"><span class="label">Foobar</span></a></li>

							-->
								<ul>
								<li><a href="index.php" id="top-link" class="skel-layers-ignoreHref"><span class="icon fa-home">Home</span></a></li>

								
							<li><a href="events.php" id="portfolio-link" class="skel-layers-ignoreHref"><span class="icon fa-th">Events</span></a>
									<li><a href="account.php" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-user">Account</span></a></li>
								<li><a href="contact.php" id="contact-link" class="skel-layers-ignoreHref"><span class="icon fa-envelope">Contact</span></a></li>
							</ul>
						</nav>

				</div>

				<div class="bottom">

					<!-- Social Icons -->
						<ul class="icons">
							<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
							<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						</ul>

				</div>

			</div>

		<!-- Main -->
			<div id="main">

				<!-- Intro -->
					<section id="top" class="one dark cover" style="margin-top: 60px;">
						<div class="container">

							<header>
								<h2 class="alt">Hi! Welcome to <strong>Mucoeh</strong>,<br />
								<p>" For The New Era of Competitons "<br /></p>
							</header>

							<footer>
								<a href="#portfolio" class="button scrolly">Let's Explore</a>
							</footer>

						</div>
					</section>

				<!-- Portfolio -->
					<section id="portfolio" class="two">
						<div class="container">

							<header>
								<h2> Upcoming Events</h2>
							</header>


							<div class="row">
								<div class="4u 12u$(mobile)">
									<article class="item">
										<a href="#" class="image fit"><img src="images/pic04.jpg" alt="" /></a>
										<header>
											<h3>Ipsum Feugiat</h3>
										</header>
									</article>
								</div>
								<div class="4u 12u$(mobile)">
									<article class="item">
										<a href="#" class="image fit"><img src="images/pic02.jpg" alt="" /></a>
										<header>
											<h3>Magna Nullam</h3>
										</header>
									</article>
								</div>
								<div class="4u$ 12u$(mobile)">
									<article class="item">
										<a href="#" class="image fit"><img src="images/pic04.jpg" alt="" /></a>
										<header>
											<h3>Dolor Penatibus</h3>
										</header>
									</article>
								</div>
							</div>

						</div>

					</section>
	<section id="portfolio" class="two">
						<div class="container">

				
							<header>
								<h2> Passed Events</h2>
							</header>


							<div class="row">
								<div class="4u 12u$(mobile)">
									<article class="item">
										<a href="#" class="image fit"><img src="images/pic02.jpg" alt="" /></a>
										<header>
											<h3>Ipsum Feugiat</h3>
										</header>
									</article>
								</div>
								<div class="4u 12u$(mobile)">
									<article class="item">
										<a href="#" class="image fit"><img src="images/pic04.jpg" alt="" /></a>
										<header>
											<h3>Magna Nullam</h3>
										</header>
									</article>
								</div>
								<div class="4u$ 12u$(mobile)">
									<article class="item">
										<a href="#" class="image fit"><img src="images/pic06.jpg" alt="" /></a>
										<header>
											<h3>Dolor Penatibus</h3>
										</header>
									</article>
								</div>
							</div>

						</div>
					</section>

				<!-- About Me -->
					<section id="about" class="three">
						<div class="container">

							<header>
								<h2>Account Details</h2>
							</header>

							<a href="#" class="image featured"><img src="images/pic08.jpg" alt="" /></a>

							<p>Tincidunt eu elit diam magnis pretium accumsan etiam id urna. Ridiculus
							ultricies curae quis et rhoncus velit. Lobortis elementum aliquet nec vitae
							laoreet eget cubilia quam non etiam odio tincidunt montes. Elementum sem
							parturient nulla quam placerat viverra mauris non cum elit tempus ullamcorper
							dolor. Libero rutrum ut lacinia donec curae mus vel quisque sociis nec
							ornare iaculis.</p>

						</div>
					</section>


			</div>


		<!-- Footer -->
			<div id="footer" style="padding-top: 10px;padding-bottom:10px;background-color: transparent;color: #1cb495;">

				<!-- Copyright -->
						<ul class="copyright">
					<li>&copy; Mucoeh 2018 | All rights reserved.</a>
				</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollzer.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>