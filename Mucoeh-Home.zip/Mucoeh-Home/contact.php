

<!DOCTYPE HTML>
<html>
	<head>
		<title>Mucoeh | Home</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>

		<!-- Header -->
			<div id="header">

				<div class="top">

					<!-- Logo -->
						<div id="logo">
							<span class=""><img src="" alt="" /></span>
							<h1 id="title" style="text-align: center;font-size: 60px;">Mucoeh</h1>
							<p style="text-align: center;"><strong>MU&nbsp;</strong>-&nbsp;Multiple&nbsp;<strong>CO&nbsp;</strong>-&nbsp;College&nbsp;<br><strong>E&nbsp;</strong>-&nbsp;Event&nbsp;<strong>H&nbsp;</strong>-&nbsp;Hoster<br />
								<br>
				            "For The New Era of Competitons"</p>
						</div>

					<!-- Nav -->
						<nav id="nav">
							<!--

								1. Hash link (scrolls to a different section within the page)

								   <li><a href="#foobar" id="foobar-link" class="icon fa-whatever-icon-you-want skel-layers-ignoreHref"><span class="label">Foobar</span></a></li>

								2. Standard link (sends the user to another page/site)

								   <li><a href="http://foobar.tld" id="foobar-link" class="icon fa-whatever-icon-you-want"><span class="label">Foobar</span></a></li>

							-->
							<ul>
								<li><a href="index.php" id="top-link" class="skel-layers-ignoreHref"><span class="icon fa-home">Home</span></a></li>

								
							<li><a href="events.php" id="portfolio-link" class="skel-layers-ignoreHref"><span class="icon fa-th">Events</span></a>
									<li><a href="account.php" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-user">Account</span></a></li>
								<li><a href="contact.php" id="contact-link" class="skel-layers-ignoreHref"><span class="icon fa-envelope">Contact</span></a></li>
							</ul>
						</nav>

				</div>

				<div class="bottom">

					<!-- Social Icons -->
						<ul class="icons">
							<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
							<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						</ul>

				</div>

			</div>

		<!-- Main -->
			<div id="main">

<style type="text/css">
	
.button {
    background-color: transparent;
    border: none;
    color: #1cb495;;
    padding: 20px 36px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}


.button3 {
    background-color: transparent; 
    color: #1cb495;; 
    border: 2px solid #1cb495;;
}

.button3:hover {
    background-color: #1cb495;;
    color: white;
}
</style>




</style>
				<!-- Contact -->
					<section id="contact" class="four" style="background-image: url('./images/contactus.jpg');padding-bottom: 40px;padding-top: 40px;">
						<div class="container">

							<header style="margin-bottom: 10px;">
								<h2 style="color: white;">Contact Us</h2>
							</header>

							<p style="color: white;">For any queries, Just drop a mail to us.<br>We will get back to you.</p>

							<form method="post" action="#">
								<div class="row">
									<div class="6u 12u$(mobile)"><input type="text" name="name" placeholder="Name" /></div>
									<div class="6u$ 12u$(mobile)"><input type="text" name="email" placeholder="Email" /></div>
									<div class="12u$">
										<input type="text" name="message" placeholder="Query" style="height: 4.6em;" />
									</div>
									<div class="12u$">
										<button id="myBtn" class="button button3">Send Query</button>
									</div>
								</div>
							</form>

						</div>
					</section>

			</div>

		<!-- Footer -->
			<div id="footer" style="padding-top: 10px;padding-bottom:10px;background-color: transparent;color: #1cb495;">

				<!-- Copyright -->
						<ul class="copyright">
					<li>&copy; Mucoeh 2018 | All rights reserved.</a>
				</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollzer.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>